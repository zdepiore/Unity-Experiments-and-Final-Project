using System.Collections;  
using System.Collections.Generic;  
using UnityEngine;  
  
public class Script : MonoBehaviour{  
  
    public int = 6;  
  
    void Start () {   
        if (myNumber > ) {  
            print ("0 > 5");  
        }  
    }  
   