using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{
	Public int health;

	void Update()
	{
		if(sphere < 0)
		{
			Rolling();
		{
	}
} 