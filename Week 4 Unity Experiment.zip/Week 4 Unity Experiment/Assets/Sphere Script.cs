Void Update()
{
	update+=Time.deltaTime
	if (update>1.0f)
	{
	   (update=0.0f;
		{
	{
{
